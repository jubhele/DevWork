/* ═══════════════════════════════════════════════════════
   API LAYER - PHP/MySQL Backend
   All data operations go through fetch() to /api/ endpoints
═══════════════════════════════════════════════════════ */

const API_BASE = (() => {
  // Derive API base relative to current page so it works both locally and in production
  const p = window.location.pathname.replace(/\/[^\/]*$/, '');
  return (p || '') + '/api';
})();

async function api(method, endpoint, data = null) {
  const opts = {
    method,
    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest' },
    credentials: 'same-origin',
  };
  if (data && method.toUpperCase() !== 'GET' && method.toUpperCase() !== 'HEAD') opts.body = JSON.stringify(data);
  try {
    const res = await fetch(API_BASE + '/' + endpoint, opts);
    if (res.status === 401) {
      const body = await res.json().catch(() => ({}));
      if (SESSION) {
        // Active session was invalidated server-side
        SESSION = null;
        document.documentElement.dataset.state = 'login';
        showLoginPanel();
        toast('Session expired. Please log in again.', 'err');
        return { success: false, error: 'Session expired' };
      }
      // No session — pass server error through (e.g. failed login attempt)
      return { success: false, ...body };
    }
    return await res.json();
  } catch (e) {
    console.error('API error:', e);
    return { success: false, error: String(e) };
  }
}

/* ── File upload helper (multipart, not JSON) ──────────────────────── */
async function apiUpload(entityType, entityRef, fileInput) {
  if (!fileInput.files.length) return { success: false, error: 'No file selected' };
  const fd = new FormData();
  fd.append('entity_type', entityType);
  fd.append('entity_ref',  entityRef);
  fd.append('file', fileInput.files[0]);
  try {
    const res = await fetch(API_BASE + '/files.php', {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'X-Requested-With': 'XMLHttpRequest' },
      body: fd,
    });
    if (res.status === 401) {
      if (typeof SESSION !== 'undefined' && SESSION) {
        SESSION = null;
        document.documentElement.dataset.state = 'login';
        if (typeof showLoginPanel === 'function') showLoginPanel();
        if (typeof toast === 'function') toast('Session expired. Please log in again.', 'err');
      }
      return { success: false, error: 'Session expired' };
    }
    return await res.json();
  } catch (e) {
    return { success: false, error: String(e) };
  }
}

/* ── data-action click dispatcher ──────────────────────────────────── */
document.addEventListener('click', function(e) {
  const el = e.target.closest('[data-action]');
  if (!el) return;
  const action = el.dataset.action;
  switch (action) {
    case 'toggleTheme':         toggleTheme(); break;
    case 'toggleInfoMode':      toggleInfoMode(); break;
    case 'goLogin':             goLogin(); break;
    case 'goPublic':            goPublic(); break;
    case 'goPublicFullscreen':  goPublicFullscreen(); break;
    case 'doLogin':             doLogin(); break;
    case 'showForgotPassword':  showForgotPassword(); break;
    case 'showLoginPanel':      showLoginPanel(); break;
    case 'doRequestReset':      doRequestReset(); break;
    case 'doResetPassword':     doResetPassword(); break;
    case 'doLogout':            doLogout(); break;
    case 'submitContact':       submitContact(); break;
    case 'openTxModal':         openTxModal(); break;
    case 'saveCallout':         saveCallout(); break;
    case 'addLine':             addLine(); break;
    case 'saveQuote':           saveQuote(); break;
    case 'saveInvoice':         saveInvoice(); break;
    case 'logPayment':          logPayment(); break;
    case 'openCreateUserModal': openCreateUserModal(); break;
    case 'closeModalDirect':    closeModalDirect(); break;
    case 'scrollToTop':         scrollToTop(); break;
    // Clients module
    case 'saveClient':          saveClient(); break;
    // Safety module
    case 'newSafetyAudit':      newSafetyAudit(); break;
    case 'saveSafetyDraft':     saveSafetyDraft(); break;
    case 'submitSafetyAudit':   submitSafetyAudit(); break;
    case 'editSafetyFile':      editSafetyFile(); break;
    case 'sendPolicyEmail':     sendPolicyEmail(); break;
    case 'approveSafetyFile':   approveSafetyFile(); break;
    // Info/guide panel
    case 'submitInfoSuggestion': submitInfoSuggestion(el.dataset.page); break;
    case 'navPage':              showPortalPage(el.dataset.page, null); break;
  }
});

/* ── Attachments modal / panel ─────────────────────────────────────── */
function openAttachmentsModal(entityType, entityRef) {
  openModal('Attachments — ' + entityRef,
    `<div id="attach-modal-area"></div>`);
  loadAttachments(entityType, entityRef);
}

async function loadAttachments(entityType, entityRef) {
  const area = document.getElementById('attach-modal-area');
  if (!area) return;
  const r = await api('GET', `files.php?action=list&entity_type=${encodeURIComponent(entityType)}&entity_ref=${encodeURIComponent(entityRef)}`);
  const canDel = SESSION && ['admin','manager'].includes(SESSION.role);
  const list = (r.attachments || []);
  const fileIcon = m => m === 'application/pdf' ? '📄' : m.includes('sheet') || m.includes('excel') ? '📊' : m.includes('word') ? '📝' : m.includes('image') ? '🖼' : '📎';
  const fmtBytes = b => b < 1024 ? b + ' B' : b < 1048576 ? (b/1024).toFixed(1) + ' KB' : (b/1048576).toFixed(1) + ' MB';
  area.innerHTML = `
    <div style="margin-bottom:12px">
      <div style="font-family:'IBM Plex Mono',monospace;font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:8px">📎 Files (${list.length})</div>
      ${list.length ? list.map(a => `
        <div style="display:flex;align-items:center;gap:8px;padding:8px 10px;background:var(--surface2);border:1px solid var(--border);border-radius:2px;margin-bottom:6px">
          <span style="font-size:18px">${fileIcon(a.mime_type)}</span>
          <div style="flex:1;min-width:0">
            <div style="font-size:12px;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${esc(a.original_name)}</div>
            <div style="font-size:10px;color:var(--muted)">${fmtBytes(a.file_size)} · ${esc(a.uploaded_by)} · ${(a.created_at||'').slice(0,10)}</div>
          </div>
          <a href="${API_BASE}/files.php?action=download&id=${a.id}" target="_blank" class="btn btn-g btn-s" style="text-decoration:none">↓ Download</a>
          ${canDel ? `<button class="btn btn-g btn-s" style="color:var(--ember)" onclick="deleteAttachment(${a.id},'${esc(entityType)}','${esc(entityRef)}')">✕</button>` : ''}
        </div>`).join('') : '<div style="font-size:11px;color:var(--muted);font-style:italic;margin-bottom:8px">No files attached yet</div>'}
    </div>
    <div style="padding-top:12px;border-top:1px solid var(--border)">
      <div style="font-family:'IBM Plex Mono',monospace;font-size:9px;text-transform:uppercase;letter-spacing:.08em;color:var(--muted);margin-bottom:8px">Upload File</div>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
        <input type="file" id="attach-file-input" accept=".pdf,.xlsx,.xls,.docx,.doc,.jpg,.jpeg,.png"
          style="flex:1;min-width:0;font-size:11px;padding:6px;background:var(--surface2);border:1px solid var(--border);border-radius:2px;color:var(--text)">
        <button class="btn btn-p btn-s" onclick="uploadAttachment('${esc(entityType)}','${esc(entityRef)}')">Upload</button>
      </div>
      <div style="font-size:10px;color:var(--muted);margin-top:4px">PDF, Excel, Word, JPEG, PNG · Max 10 MB</div>
    </div>`;
}

async function uploadAttachment(entityType, entityRef) {
  const inp = document.getElementById('attach-file-input');
  if (!inp || !inp.files.length) { toast('Select a file first', 'err'); return; }
  const btn = document.querySelector('#attach-modal-area .btn-p');
  if (btn) { btn.disabled = true; btn.textContent = 'Uploading…'; }
  const r = await apiUpload(entityType, entityRef, inp);
  if (!r.success) {
    toast(r.error || 'Upload failed', 'err');
    if (btn) { btn.disabled = false; btn.textContent = 'Upload'; }
    return;
  }
  toast('File attached', 'ok');
  await loadAttachments(entityType, entityRef);
}

async function deleteAttachment(id, entityType, entityRef) {
  if (!confirm('Remove this file?')) return;
  const r = await api('DELETE', `files.php?id=${id}`);
  if (!r.success) { toast(r.error || 'Delete failed', 'err'); return; }
  toast('File removed', 'ok');
  await loadAttachments(entityType, entityRef);
}

/* ═══════════════════════════════════════════════════════
   PERMISSIONS MAP (mirrors server-side PERMS)
═══════════════════════════════════════════════════════ */
const PERMS = {
  'callout.view':          ['admin','manager','call_logger','junior_tech','senior_tech','client_support','admin_clerk','viewer'],
  'callout.create':        ['admin','manager','call_logger','client_support'],
  'callout.update_status': ['admin','manager','call_logger','junior_tech','senior_tech','admin_clerk'],
  'callout.assign_po':     ['admin','manager','admin_clerk'],
  'callout.assign_tech':   ['admin','manager','admin_clerk'],
  'callout.delete':        ['admin','manager'],
  'quote.view':            ['admin','manager','senior_tech','client_support','admin_clerk','viewer'],
  'quote.create':          ['admin','manager','senior_tech'],
  'quote.approve':         ['admin','manager'],
  'quote.convert':         ['admin','manager','admin_clerk'],
  'quote.delete':          ['admin','manager'],
  'invoice.view':          ['admin','manager','client_support','admin_clerk','viewer'],
  'invoice.create':        ['admin','manager','admin_clerk'],
  'invoice.mark_paid':     ['admin','manager','admin_clerk'],
  'invoice.delete':        ['admin','manager'],
  'finance.transactions':  ['admin','sysadmin','manager','admin_clerk'],
  'finance.statement':     ['admin','sysadmin','manager','client_support','admin_clerk'],
  'finance.income':        ['admin','sysadmin','manager','admin_clerk'],
  'capture.new_callout':   ['admin','sysadmin','manager','call_logger','client_support'],
  'capture.new_quote':     ['admin','sysadmin','manager','senior_tech'],
  'capture.new_invoice':   ['admin','sysadmin','manager','admin_clerk'],
  'capture.log_payment':   ['admin','sysadmin','manager','admin_clerk'],
  'security.audit':        ['admin','sysadmin'],
  'security.users':        ['admin','sysadmin','manager','admin_clerk'],
  'user.create':           ['admin','sysadmin','manager','admin_clerk'],
  'user.update':           ['admin','sysadmin'],
  'callout.confirm_closure':   ['admin','sysadmin','manager'],
  'invoice.send':              ['admin','sysadmin','manager','admin_clerk'],
  'finance.statement.release': ['admin','sysadmin','manager','admin_clerk'],
  'finance.statement.generate':['admin','sysadmin'],
  'clients.view':              ['admin','sysadmin','manager','admin_clerk','client_support'],
  'clients.create':            ['admin','sysadmin','manager','admin_clerk'],
  'clients.update':            ['admin','sysadmin','manager','admin_clerk'],
};
function can(perm){ return SESSION?.role==='sysadmin' || (PERMS[perm]||[]).includes(SESSION?.role); }

/* ═══════════════════════════════════════════════════════
   IN-MEMORY CACHE (populated from API on login/refresh)
═══════════════════════════════════════════════════════ */
let DB = { callouts:[], quotes:[], invoices:[], bank:[], users:[], safetyFiles:[], clients:[] };
let SESSION = null;
let AUDIT_LOG = [];

